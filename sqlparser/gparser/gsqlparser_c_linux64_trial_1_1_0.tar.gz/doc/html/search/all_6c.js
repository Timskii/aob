var searchData=
[
  ['limitvalue',['limitValue',['../structgsp__limit_clause.html#a4e38db8b44b68669cf8f08e30ee7265d',1,'gsp_limitClause']]],
  ['lockedobjects',['lockedObjects',['../structgsp__locking_clause.html#a3b281813339836a8345e580cf0c6bf37',1,'gsp_lockingClause']]]
];
