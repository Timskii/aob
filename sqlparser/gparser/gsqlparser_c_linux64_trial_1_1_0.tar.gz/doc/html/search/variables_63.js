var searchData=
[
  ['columnlist',['columnList',['../structgsp__collect_statistics_sql_node.html#a42e79640896f69404adee59401d8e1ee',1,'gsp_collectStatisticsSqlNode']]],
  ['countfractiondescriptionlist',['countFractionDescriptionList',['../structgsp__sample_clause.html#a183571bcc5b4602621261a5dd71d45ca',1,'gsp_sampleClause']]]
];
