var searchData=
[
  ['gsp_5fdbvendor_5fname',['gsp_dbvendor_name',['../gsp__base_8h.html#a6bc91ab5d47c17977eadbf426daa7885',1,'gsp_base.h']]]
];
