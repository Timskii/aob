var searchData=
[
  ['text',['text',['../structgsp__fragment.html#a1278e4a38c27d0b67255d44608390e49',1,'gsp_fragment']]]
];
