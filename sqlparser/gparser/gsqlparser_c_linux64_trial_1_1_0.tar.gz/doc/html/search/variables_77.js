var searchData=
[
  ['whenthenlist',['whenThenList',['../structgsp__sample_clause.html#ad0f70571b079af790e29ab686338ddec',1,'gsp_sampleClause']]],
  ['windownsdefs',['windownsDefs',['../structgsp__window_clause.html#abb95562bcea1fd9e04d4d53a9e6e0f0e',1,'gsp_windowClause']]]
];
