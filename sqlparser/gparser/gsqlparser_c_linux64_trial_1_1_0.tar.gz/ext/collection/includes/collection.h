#ifndef   COLLECTION_H
#define   COLLECTION_H

#ifdef __cplusplus
extern "C" {
#endif

#include "c_pair.h"

#define BOOL int
#define TRUE 1
#define FALSE 0

#define Entry _c_pair
#define Iterator _c_iterator

#define PRIVATE

#ifdef __cplusplus
}
#endif

#endif /* COLLECTION_H */
